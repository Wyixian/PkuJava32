import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Stack;

import javax.imageio.*;
import javax.swing.*;
import javax.swing.text.StyledEditorKit.ForegroundAction;

public class GoBangGame extends JFrame implements MouseListener,
		MouseMotionListener, Runnable {
	int x = 0, nx = 0;
	int y = 0, ny = 0;
	long maxTime = 0, blackTime = 0, whiteTime = 0;
	String blackMessage = "__";
	String whiteMessage = "__";
	// isBlack = 1 ��ʾ�ڷ���isBlack = 0��ʾ�׷�
	int isBlack = 1;
	public String message = "�ڷ�����";

	// ������������0����ʾ�����û�����ӣ�1��ʾ������Ǻ��ӣ�2��ʾ������ǰ���
	int[][] points = new int[15][15];
	// cGrades��pGrades�ֱ����ڱ�������ӵı��
	boolean[][][] cMarks = new boolean[15][15][572];
	boolean[][][] pMarks = new boolean[15][15][572];
	// pGrades��cGrades�ֱ��¼ÿ����ķ���
	int[][] pGrades = new int[15][15];
	int[][] cGrades = new int[15][15];
	int pMGrad, pMx, pMy;
	int cMGrad, cMx, cMy;

	// weights���ڱ��ÿ���հ׵��Ȩֵ,weights[0][]Ϊ���ԣ�weights[1][]Ϊ���
	int[][] weights = new int[2][572];

	Stack<Integer> stack = new Stack<>();
	private boolean canPlay = true;

	BufferedImage bi;
	Graphics g1;
	boolean peopletopeople = false;
	boolean start = true;

	public GoBangGame() {
		this.setTitle("������(by ��(you)��");
		this.setIconImage(Toolkit.getDefaultToolkit().createImage("2.png"));
		int width = Toolkit.getDefaultToolkit().getScreenSize().width;
		int height = Toolkit.getDefaultToolkit().getScreenSize().height;
		this.setBounds(width / 2 - 318, height / 2 - 250, 635, 500);
		this.setVisible(true);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
		resetMarks();
	}

	public static void main(String[] args) {
		GoBangGame gbg = new GoBangGame();
		/* JOptionPane.showMessageDialog(gbg, "�ҵ���Ϣ"); */
		/*
		 * String username = JOptionPane.showInputDialog("����������");
		 * JOptionPane.showConfirmDialog(gbg, username);
		 * System.out.println(username);
		 */
		/*
		 * int result = JOptionPane.showConfirmDialog(gbg, "����Ҫ��ʼ��Ϸ��");
		 * if(result == 0) { JOptionPane.showMessageDialog(gbg, "��Ϸ��ʼ"); }
		 * if(result == 1) { JOptionPane.showMessageDialog(gbg, "��Ϸ����"); }
		 * if(result == 2) { JOptionPane.showMessageDialog(gbg, "������ѡ��"); }
		 */
	}

	@Override
	public void paint(Graphics g) {
		BufferedImage image = null;
		try {
			// ˫���弼����ֹ��˸,��ʹ��BufferedIamge��
			image = ImageIO.read(new File("1.png"));
			bi = new BufferedImage(635, 500, BufferedImage.TYPE_INT_ARGB);
			g1 = bi.createGraphics();
			g1.drawImage(image, 0, 0, this);
			g1.setFont(new Font("����", Font.BOLD, 16));
			g1.setColor(Color.BLACK);
			g1.drawString("��Ϸ��Ϣ:  " + message, 230, 36);
			g1.drawString("����", 210, 448);
			g1.drawString("����", 152, 448);
			g1.drawString("ʱ��", 385, 448);

			g1.setFont(new Font("����", 0, 12));
			g1.setColor(Color.RED);
			g1.drawString("����ʱ:", 150, 20);
			g1.drawImage(ImageIO.read(new File("3_1.png")), 135, 9, this);
			g1.drawString("����ʱ:", 425, 20);
			g1.setColor(Color.gray);
			g1.drawString(blackMessage, 195, 20);
			g1.drawString(whiteMessage, 470, 20);
			g1.drawImage(ImageIO.read(new File("4_2.png")), 405, 9, this);
			if (canPlay) {
				g1.setColor(Color.CYAN);
				g1.drawRect(151 + nx * 22, 68 + ny * 22, 22, 22);
			}

			for (int i = 0; i < 15; i++) {
				for (int j = 0; j < 15; j++) {
					if (points[i][j] == 1) {
						g1.drawImage(ImageIO.read(new File("3.png")),
								154 + i * 22, 71 + j * 22, this);
						// g1.setColor(Color.BLACK);
						// g1.fillOval(163 + i * 22 - 8, 79 + j * 22 - 8, 16,
						// 16);
					} else if (points[i][j] == 2) {
						// g1.setColor(Color.WHITE);
						g1.drawImage(ImageIO.read(new File("4.png")),
								154 + i * 22, 71 + j * 22, this);
					}
				}
			}
			if (!canPlay) {
				g1.setFont(new Font("����", 0, 24));
				g1.setColor(Color.CYAN);
				g1.drawString("��Ϸ������", 265, 220);
			}
			g.drawImage(bi, 0, 22, this);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		int x = e.getX(), y = e.getY();
		if (x <= 372 && x >= 330 && y <= 477 && y >= 452) {
			JOptionPane
					.showMessageDialog(
							this,
							"<html><font color=black face =����  size=3"
									+ ">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp�ڰ�˫���������ӣ��ɺ����£���һ����<br/>"
									+ "���������γɺ�������б�����������ͬ<br/>��ɫ���������������ϣ����ӵ�һ��Ϊʤ��</font></html>",
							"��Ϸ����", JOptionPane.DEFAULT_OPTION);
		}
		if (canPlay && x >= 262 && x <= 304 && y <= 477 && y >= 452) {
			if (stack.isEmpty())
				JOptionPane
						.showMessageDialog(
								this,
								"<html><font <html><font color=black text-align=center face =����  size=3`>��������û�����ӣ��޷����壡</font></html>");
			else {
				points[stack.pop()][stack.pop()] = 0;
				isBlack = stack.pop();
				if (isBlack == 1)
					message = "�ֵ��ڷ�";
				else
					message = "�ֵ��׷�";
				repaint();
			}
		}
		// ���䰴ť
		if (canPlay && x >= 204 && x <= 239 && y <= 477 && y >= 448) {
			int result = JOptionPane.showConfirmDialog(this,
					"<html><font face=���� size=5>ȷ�����䣿</font></html>");
			if (result == 0) {
				canPlay = false;
				if (isBlack == 1) {
					message = "�ڷ�������";
				} else {
					message = "�׷�������";
				}
			}
			repaint();
		}
		// ���¿�ʼ
		if (x >= 150 && x <= 174 && y <= 477 && y >= 448) {
			int result = JOptionPane.showConfirmDialog(this,
					"<html><font face=���� size=5>ȷ�����¿�ʼ��</font></html>");
			if (result == 0) {
				canPlay = true;
				message = "�ڷ�����";
				isBlack = 1;
				blackTime = maxTime;
				whiteTime = maxTime;
				points = new int[15][15];
				stack.clear();
			}
			resetMarks();
		}
		// ����
		if (x >= 385 && x <= 422 && y <= 477 && y >= 452) {
			String input = JOptionPane
					.showInputDialog(
							this,
							"<html><font face=���� size=3>������ʱ������(��),0Ϊ������:</font></html>",
							"ʱ������", JOptionPane.PLAIN_MESSAGE);
			try {
				maxTime = Integer.valueOf(input) * 60;
				if (maxTime < 0)
					JOptionPane.showMessageDialog(this,
							"<html><font face=���� size=6>��ȷʱ�䣡</font></html>",
							"ʱ������", JOptionPane.PLAIN_MESSAGE);
				if (maxTime >= 0) {
					blackTime = maxTime;
					whiteTime = maxTime;
					int result = JOptionPane
							.showConfirmDialog(this,
									"<html><font face=���� size=3>��Ϸ�����ѳɹ����ģ��Ƿ����¿�ʼ��Ϸ��</font></html>");
					if (result == 0) {
						canPlay = true;
						message = "�ڷ�����";
						isBlack = 1;
						points = new int[15][15];
					}
					Thread t = new Thread(this);
					t.start();
				}
			} catch (NumberFormatException e1) {
				// TODO Auto-generated catch block
				if (input != null)
					JOptionPane
							.showMessageDialog(
									this,
									"<html><font face=���� size=5>��ȷ������ʱ���ʽ��ȷ��</font></html>",
									"��ܰ��ʾ", JOptionPane.PLAIN_MESSAGE);
			}
		}
		// System.out.println(x+" " + y);
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// ��������(163,101)������(471,101)������(163,409)������(471,409).��14��,ÿ�񳤶�Ϊ22
		if (canPlay) {
			x = e.getX();
			y = e.getY();
			if (x >= 163 && x <= 471 && y >= 101 && y <= 409) {
				x = x - 163;
				nx = x / 22;
				if (x % 22 >= 11)
					nx++;
				y = y - 101;
				ny = y / 22;
				if (y % 22 >= 11)
					ny++;
				if (points[nx][ny] == 0) {
					if (isBlack == 1) { // �ڷ�
						points[nx][ny] = 1;
						for (int k = 0; k < 572; k++) {
							if (pMarks[nx][ny][k] && weights[1][k] != 7) {
								weights[1][k]++;
							}
							if (cMarks[nx][ny][k]) {
								cMarks[nx][ny][k] = false;
								weights[0][k] = 7;
							}
						}
						isBlack = 0;
						message = "�ֵ��׷�";
					} else if (peopletopeople && isBlack == 0) {
						if (peopletopeople) {
							points[nx][ny] = 2;
							isBlack = 1;
							message = "�ֵ��ڷ�";
						}
					}
				}
				stack.add(isBlack);
				stack.add(ny);
				stack.add(nx);
				if (points[nx][ny] != 0 && Check.checkWinner(nx, ny, points)) {
					if (points[nx][ny] == 1) {
						message = "�ڷ���ʤ";
						JOptionPane
								.showMessageDialog(
										this,
										"<html><font color=black face =����  size=6>��Ϸ�������ڷ���ʤ��</font></html>",
										"��Ϸ�����", JOptionPane.DEFAULT_OPTION);
					}
					if (points[nx][ny] == 2) {
						message = "�׷���ʤ";
						JOptionPane
								.showMessageDialog(
										this,
										"<html><font color=black face =����  size=6>��Ϸ�������׷���ʤ��</font></html>",
										"��Ϸ�����", JOptionPane.DEFAULT_OPTION);
					}
					canPlay = false;
				}
				if(!peopletopeople) {
					computerdo();
					isBlack = 1;
					points[nx][ny] = 2;
					message = "�ֵ���";
					if (points[nx][ny] != 0 && Check.checkWinner(nx, ny, points)) {
						if (points[nx][ny] == 1) {
							message = "�ڷ���ʤ";
							JOptionPane
									.showMessageDialog(
											this,
											"<html><font color=black face =����  size=6>��Ϸ�������ڷ���ʤ��</font></html>",
											"��Ϸ�����", JOptionPane.DEFAULT_OPTION);
						}
						if (points[nx][ny] == 2) {
							message = "�׷���ʤ";
							JOptionPane
									.showMessageDialog(
											this,
											"<html><font color=black face =����  size=6>��Ϸ�������׷���ʤ��</font></html>",
											"��Ϸ�����", JOptionPane.DEFAULT_OPTION);
						}
						canPlay = false;
					}
					stack.add(isBlack);
					stack.add(ny);
					stack.add(nx);
				}
			}
			repaint();
		}
	}

	public void computerdo() {
		cMGrad = 0;
		if (start) {
			while (true) {
				int tx = (int) (Math.random() * 2);
				int ty = (int) (Math.random() * 2);
				nx = 6 + tx;
				ny = 6 + ty;
				if (points[nx][ny] == 0)
					break;
			}
			start = false;
		} else {
			for (int i = 0; i < 15; i++)
				for (int j = 0; j < 15; j++) {
					cGrades[i][j] = 0; // �õ��������
					if (points[i][j] == 0) {
						for (int k = 0; k < 572; k++) {
							if (cMarks[i][j][k])
								switch (weights[0][k]) {
								case 1:
									cGrades[i][j] += 5;
									break;
								case 2:
									cGrades[i][j] += 50;
									break;
								case 3:
									cGrades[i][j] += 100;
									break;
								case 4:
									cGrades[i][j] += 400;
									break;
								default:
									break;
								}
						}
					}
					if (cMGrad < cGrades[i][j]) {
						cMGrad = cGrades[i][j];
						cMx = i;
						cMy = j;
					}
				}
			pMGrad = 0;

			for (int i = 0; i < 15; i++)
				for (int j = 0; j < 15; j++) {
					pGrades[i][j] = 0;
					if (points[i][j] == 0) {
						for (int k = 0; k < 572; k++) {
							if (pMarks[i][j][k])
								switch (weights[1][k]) {
								case 1:
									pGrades[i][j] += 5;
									break;
								case 2:
									pGrades[i][j] += 52;
									break;
								case 3:
									pGrades[i][j] += 110;
									break;
								case 4:
									pGrades[i][j] += 400;
									break;
								default:
									break;
								}
						}
					}
					if (pMGrad < pGrades[i][j]) {
						pMGrad = pGrades[i][j];
						pMx = i;
						pMy = j;
					}
					// System.out.print("*" + pMGrad);
				}
			if (pMGrad >= cMGrad && pMGrad > 100) { // ����
				nx = pMx;
				ny = pMy;
			} else {
				nx = cMx;
				ny = cMy;
			}

		}
		System.out.println(cMGrad + " " + pMGrad + "********");
		points[nx][ny] = 2;
		for (int k = 0; k < 572; k++) {
			if (cMarks[nx][ny][k] && weights[0][k] != 7) {
				weights[0][k]++;
			}
			if (pMarks[nx][ny][k]) {
				pMarks[nx][ny][k] = false;
				weights[1][k] = 7;
			}
		}
		repaint();
	}

	public void resetMarks() {
		int count = 0;
		// ����
		for (int i = 0; i < 15; i++)
			for (int j = 0; j < 11; j++) {
				for (int k = 0; k < 5; k++) {
					cMarks[i][j + k][count] = true;
					pMarks[i][j + k][count] = true;
				}
				count++;
			}
		// ����
		for (int i = 0; i < 11; i++)
			for (int j = 0; j < 15; j++) {
				for (int k = 0; k < 5; k++) {
					cMarks[i + k][j][count] = true;
					pMarks[i + k][j][count] = true;
				}
				count++;
			}
		// ���Խ�
		for (int i = 0; i < 11; i++)
			for (int j = 0; j < 11; j++) {
				for (int k = 0; k < 5; k++) {
					cMarks[i + k][j + k][count] = true;
					pMarks[i + k][j + k][count] = true;
				}
				count++;
			}
		// ���Խ�
		for (int i = 0; i < 11; i++)
			for (int j = 14; j > 3; j--) {
				for (int k = 0; k < 5; k++) {
					cMarks[i + k][j - k][count] = true;
					pMarks[i + k][j - k][count] = true;
				}
				count++;
			}
		// ��ʼ��ÿ���ڰ��ӵ��Ȩֵ
		for (int i = 0; i <= 1; i++)
			for (int j = 0; j < 572; j++)
				weights[i][j] = 0;
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		// JOptionPane.showMessageDialog(this, "����ͷ���");

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		x = e.getX();
		y = e.getY();
		if (x >= 163 && x <= 471 && y >= 101 && y <= 409) {
			if (isBlack == 1) {
				Image img = new ImageIcon("32.png").getImage();
				Cursor myCursor = Toolkit.getDefaultToolkit()
						.createCustomCursor(img, new Point(5, 5), "hd");
				this.setCursor(myCursor);
			} else {
				Image img = new ImageIcon("42.png").getImage();
				Cursor myCursor = Toolkit.getDefaultToolkit()
						.createCustomCursor(img, new Point(5, 5), "hd");
				this.setCursor(myCursor);
			}
			x = x - 163;
			nx = x / 22;
			if (x % 22 >= 11)
				nx++;
			y = y - 101;
			ny = y / 22;
			if (y % 22 >= 11)
				ny++;
		} else if (canPlay && x >= 262 && x <= 304 && y <= 477 && y >= 452) {
			// ����
			this.setCursor(Cursor.HAND_CURSOR);
		} else if (x <= 372 && x >= 330 && y <= 477 && y >= 452) {
			// ˵��
			this.setCursor(Cursor.HAND_CURSOR);
		} else if (canPlay && x >= 208 && x <= 248 && y <= 477 && y >= 452) {
			// ����
			this.setCursor(Cursor.HAND_CURSOR);
		} else if (x >= 150 && x <= 191 && y <= 477 && y >= 452) {
			// ���¿�ʼ
			this.setCursor(Cursor.HAND_CURSOR);
		} else if (x >= 385 && x <= 422 && y <= 477 && y >= 452) {
			// ����
			this.setCursor(Cursor.HAND_CURSOR);
		} else {
			this.setCursor(Cursor.DEFAULT_CURSOR);
		}
		repaint();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		if (maxTime > 0) {
			whiteTime = maxTime;
			blackTime = maxTime;
			while (true) {
				if (isBlack == 1) {
					blackTime--;
					blackMessage = blackTime / 60 + "��" + blackTime % 60 + "��";
					if (blackTime == 0) {
						canPlay = false;
						message = "�ڷ��ѳ�ʱ";
						break;
					}
				} else {
					whiteTime--;
					whiteMessage = whiteTime / 60 + "��" + whiteTime % 60 + "��";
					if (blackTime == 0) {
						canPlay = false;
						message = "�׷��ѳ�ʱ";
						break;
					}
				}
				try {
					Thread.sleep(1000);
				} catch (Exception e) {
					// TODO: handle exception
				}
				repaint();
			}
		}
	}
}

class Check {
	public static int checkLeft(int nx, int ny, int[][] points) {
		int count = 0;
		for (int i = nx - 1; i >= 0; i--) {
			if (points[i][ny] != points[nx][ny])
				break;
			count++;
		}
		return count;
	}

	public static int checkRight(int nx, int ny, int[][] points) {
		int count = 0;
		for (int i = nx + 1; i < 15; i++) {
			if (points[i][ny] != points[nx][ny])
				break;
			count++;
		}
		return count;
	}

	public static int checkUp(int nx, int ny, int[][] points) {
		int count = 0;
		for (int j = ny - 1; j >= 0; j--) {
			if (points[nx][j] != points[nx][ny])
				break;
			count++;
		}
		return count;
	}

	public static int checkDown(int nx, int ny, int[][] points) {
		int count = 0;
		for (int j = ny + 1; j < 15; j++) {
			if (points[nx][j] != points[nx][ny])
				break;
			count++;
		}
		return count;
	}

	public static int checkLeftUp(int nx, int ny, int[][] points) {
		int count = 0;
		for (int i = nx - 1, j = ny - 1; i >= 0 && j >= 0; i--, j--) {
			if (points[i][j] != points[nx][ny])
				break;
			count++;
		}
		return count;
	}

	public static int checkRightDown(int nx, int ny, int[][] points) {
		int count = 0;
		for (int i = nx + 1, j = ny + 1; i < 15 && j < 15; i++, j++) {
			if (points[i][j] != points[nx][ny])
				break;
			count++;
		}
		return count;
	}

	public static int checkRightUp(int nx, int ny, int[][] points) {
		int count = 0;
		for (int i = nx + 1, j = ny - 1; i < 15 && j >= 0; i++, j--) {
			if (points[i][j] != points[nx][ny])
				break;
			count++;
		}
		return count;
	}

	public static int checkLeftDown(int nx, int ny, int[][] points) {
		int count = 0;
		for (int i = nx - 1, j = ny + 1; i >= 0 && j < 15; i--, j++) {
			if (points[i][j] != points[nx][ny])
				break;
			count++;
		}
		return count;
	}

	public static boolean checkWinner(int nx, int ny, int[][] points) {
		if (checkLeft(nx, ny, points) + checkRight(nx, ny, points) >= 4)
			return true;
		if (checkUp(nx, ny, points) + checkDown(nx, ny, points) >= 4)
			return true;
		if (checkLeftUp(nx, ny, points) + checkRightDown(nx, ny, points) >= 4)
			return true;
		if (checkRightUp(nx, ny, points) + checkLeftDown(nx, ny, points) >= 4)
			return true;
		return false;
	}
}
